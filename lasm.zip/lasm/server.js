const fs = require('fs'), path = require('path'), http = require('http'), crypto = require('crypto');
// minimal .env loader (no dependencies)
try { for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) { const m = /^\s*([A-Z_]+)\s*=\s*(.*)\s*$/.exec(l); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, ''); } } catch {}
const { q, settings, BLOCKS, DATA } = require('./lib/db');
const U = require('./lib/util');
const V = require('./lib/views');
const admin = require('./lib/admin');

// first admin
if (!q.get('SELECT 1 AS x FROM users LIMIT 1')) {
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  q.run('INSERT INTO users(username,pass,role,name) VALUES(?,?,?,?)', process.env.ADMIN_USER || 'admin', U.hashPw(pw), 'admin', 'Administrator');
  console.log(`\n== पहला एडमिन बनाया गया ==\nusername: ${process.env.ADMIN_USER || 'admin'}\npassword: ${process.env.ADMIN_PASSWORD ? '(.env वाला)' : pw}\nलॉगिन के बाद पासवर्ड बदलें: /admin/users\n`);
}

const MIME = { '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const SEC = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; frame-src https://www.youtube-nocookie.com https://www.google.com; script-src 'self'; form-action 'self'; base-uri 'self'" };
const H = {
  html(res, body, code = 200) { res.writeHead(code, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', ...SEC }); res.end(body); },
  redirect(res, to, code = 303) { res.writeHead(code, { Location: to }); res.end(); },
};
function serveFile(req, res, file, maxAge) {
  fs.stat(file, (e, st) => {
    if (e || !st.isFile()) return H.html(res, 'Not found', 404);
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'public, max-age=' + maxAge, 'X-Content-Type-Options': 'nosniff' });
    fs.createReadStream(file).pipe(res);
  });
}
const safeJoin = (root, rel) => { const f = path.normalize(path.join(root, rel)); return f.startsWith(root + path.sep) ? f : null; };
const ip = req => req.socket.remoteAddress || 'x';
const cleanMobile = m => String(m || '').replace(/[\s\-+()]/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
function genAppId() {
  for (let i = 0; i < 10; i++) { const id = 'LASM-' + new Date().getFullYear() + '-' + crypto.randomInt(0, 1e6).toString().padStart(6, '0'); if (!q.get('SELECT 1 AS x FROM applications WHERE app_id=?', id)) return id; }
  throw new Error('id');
}

async function route(req, res) {
  const url = new URL(req.url, 'http://x'); const p = decodeURIComponent(url.pathname).replace(/(.)\/+$/, '$1');
  if (p.startsWith('/admin')) return admin.handle(req, res, url, H);
  if (req.method === 'GET' || req.method === 'HEAD') {
    if (p.startsWith('/uploads/')) { const f = safeJoin(path.join(DATA, 'uploads'), p.slice(9)); return f ? serveFile(req, res, f, 2592000) : H.html(res, 'Not found', 404); }
    if (/^\/(css|js|img)\//.test(p)) { const f = safeJoin(path.join(__dirname, 'public'), p.slice(1)); return f ? serveFile(req, res, f, 3600) : H.html(res, 'Not found', 404); }
    if (p === '/robots.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end(`User-agent: *\nDisallow: /admin\nSitemap: ${process.env.SITE_URL || ''}/sitemap.xml\n`); }
    if (p === '/sitemap.xml') {
      const base = process.env.SITE_URL || ''; const urls = ['/', '/about', '/organization', '/leadership', '/blocks', '/news', '/gallery', '/membership', '/donation', '/contact', '/demands', '/privacy', '/terms', ...BLOCKS.map(b => '/blocks/' + b[0]), ...q.all('SELECT slug FROM news WHERE published=1').map(n => '/news/' + n.slug)];
      res.writeHead(200, { 'Content-Type': 'application/xml' }); return res.end(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(u => `<url><loc>${base}${u}</loc></url>`).join('')}</urlset>`);
    }
  }
  const S = settings(); const L = (opts) => H.html(res, V.layout(S, { path: p, ...opts }), opts.code || 200);
  if (req.method === 'GET') {
    if (p === '/') return L({ body: V.home(S), desc: 'लोहार आदिवासी संघर्ष मंच का आधिकारिक वेबसाइट – सदस्यता, नेतृत्व, प्रखंड संगठन, खबरें।', og: S.hero_image });
    if (p === '/about') return L({ title: 'हमारे बारे में', body: V.about(S) });
    if (p === '/organization') return L({ title: 'संगठन', body: V.organization() });
    if (p === '/leadership') return L({ title: 'नेतृत्व', body: V.leadership() });
    if (p === '/blocks') return L({ title: 'हमारे प्रखंड', body: V.blocks() });
    if (p.startsWith('/blocks/')) { const b = V.blockPage(p.slice(8)); return b ? L({ title: BLOCKS.find(x => x[0] === p.slice(8))[1] + ' प्रखंड संगठन', body: b }) : L({ title: 'नहीं मिला', body: '<section class="sec"><div class="wrap"><h1>पृष्ठ नहीं मिला</h1></div></section>', code: 404 }); }
    if (p === '/news') return L({ title: 'समाज की खबरें', body: V.newsList(url.searchParams.get('f') || '') });
    if (p.startsWith('/news/')) { const n = q.get('SELECT * FROM news WHERE slug=? AND published=1', p.slice(6)); return n ? L({ title: n.title, desc: n.summary.slice(0, 150), body: V.newsDetail(n), og: n.image }) : L({ title: 'नहीं मिला', body: '<section class="sec"><div class="wrap"><h1>खबर नहीं मिली</h1></div></section>', code: 404 }); }
    if (p === '/gallery') return L({ title: 'गैलरी', body: V.gallery(url.searchParams.get('c') || '') });
    if (p === '/membership') return L({ title: 'सदस्य बनें', body: V.membership(S) });
    if (p.startsWith('/membership/success/')) {
      const a = q.get('SELECT * FROM applications WHERE app_id=?', p.slice(20)); if (!a) return H.redirect(res, '/membership');
      const fb = a.notify_status === 'sent' || !S.wa_admin_number ? '' : 'https://wa.me/' + U.waNum(S.wa_admin_number) + '?text=' + encodeURIComponent(U.appMessage(a));
      return L({ title: 'आवेदन प्राप्त हुआ', body: V.success(S, a, fb) });
    }
    if (p === '/demands') return L({ title: 'हमारी माँगें और सामाजिक मुद्दे', body: V.demands() });
    if (p === '/donation') return L({ title: 'आर्थिक सहयोग', body: V.donation(S) });
    if (p === '/contact') return L({ title: 'संपर्क करें', body: V.contact(S) });
    if (p === '/privacy') return L({ title: 'गोपनीयता नीति', body: V.privacy(S) });
    if (p === '/terms') return L({ title: 'नियम एवं शर्तें', body: V.terms(S) });
    return L({ title: 'नहीं मिला', body: '<section class="sec"><div class="wrap"><h1>पृष्ठ नहीं मिला</h1><p><a href="/">मुख्य पृष्ठ पर जाएँ</a></p></div></section>', code: 404 });
  }
  if (req.method === 'POST' && (p === '/membership' || p === '/contact')) {
    if (U.limited('f:' + ip(req), 20, 3600e3)) return L({ title: 'कृपया प्रतीक्षा करें', body: '<section class="sec"><div class="wrap"><h1>बहुत अधिक अनुरोध</h1><p>कृपया कुछ देर बाद फिर प्रयास करें।</p></div></section>', code: 429 });
    let f, files; try { ({ fields: f, files } = await U.parseForm(req)); } catch { return H.html(res, 'Request too large', 413); }
    if (f.website) { res.writeHead(303, { Location: '/' }); return res.end(); } // honeypot
    if (!U.checkFormToken(f._t)) return L({ title: 'त्रुटि', body: p === '/membership' ? V.membership(S, 'फॉर्म की अवधि समाप्त हो गई या बहुत जल्दी जमा हुआ। कृपया दोबारा जमा करें।', f) : V.contact(S, 'फॉर्म दोबारा भेजें।') });
    const t = k => String(f[k] || '').trim();
    if (p === '/contact') {
      if (!t('name') || !t('body')) return L({ title: 'संपर्क', body: V.contact(S, 'नाम और संदेश आवश्यक हैं।') });
      q.run('INSERT INTO messages(name,mobile,email,body) VALUES(?,?,?,?)', t('name').slice(0, 80), t('mobile').slice(0, 20), t('email').slice(0, 120), t('body').slice(0, 1500));
      return L({ title: 'संपर्क', body: V.contact(S, '✓ आपका संदेश मिल गया। संगठन शीघ्र संपर्क करेगा।') });
    }
    const mob = cleanMobile(f.mobile); let err = '';
    if (t('name').length < 2) err = 'कृपया पूरा नाम लिखें।';
    else if (!/^[6-9]\d{9}$/.test(mob)) err = 'कृपया 10 अंकों का सही भारतीय मोबाइल नंबर लिखें।';
    else if (t('address').length < 5) err = 'कृपया पूरा पता लिखें।';
    else if (!t('district')) err = 'जिला आवश्यक है।';
    else if (!BLOCKS.some(b => b[1] === t('block'))) err = 'कृपया सूची से अपना प्रखंड चुनें।';
    else if (!t('village')) err = 'पंचायत / गाँव आवश्यक है।';
    else if (!t('occupation')) err = 'व्यवसाय आवश्यक है।';
    else if (t('email') && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(t('email'))) err = 'ईमेल सही नहीं है।';
    else if (!f.consent) err = 'आगे बढ़ने के लिए सहमति देना आवश्यक है।';
    else if (q.get("SELECT 1 AS x FROM applications WHERE mobile=? AND created_at > datetime('now','-1 day')", mob)) err = 'इस मोबाइल नंबर से आवेदन पहले ही प्राप्त हो चुका है।';
    let photo = ''; if (!err) { try { photo = U.saveImage(files.photo); } catch (e) { err = e.message; } }
    if (err) return L({ title: 'सदस्य बनें', body: V.membership(S, err, f), code: 400 });
    const app = { app_id: genAppId(), name: t('name').slice(0, 80), mobile: mob, address: t('address').slice(0, 300), district: t('district').slice(0, 60), block: t('block'), village: t('village').slice(0, 100), occupation: t('occupation').slice(0, 80), email: t('email').slice(0, 120), message: t('message').slice(0, 500), photo };
    q.run('INSERT INTO applications(app_id,name,mobile,address,district,block,village,occupation,email,message,photo) VALUES(?,?,?,?,?,?,?,?,?,?,?)', ...Object.values(app));
    const st = await U.notifyAdmin(app, S.wa_admin_number);
    q.run('UPDATE applications SET notify_status=? WHERE app_id=?', st, app.app_id);
    return H.redirect(res, '/membership/success/' + app.app_id);
  }
  return H.html(res, 'Method not allowed', 405);
}
const server = http.createServer((req, res) => {
  Object.entries(SEC).forEach(([k, v]) => res.setHeader(k, v));
  route(req, res).catch(e => { console.error(e); if (!res.headersSent) H.html(res, '<h1>कुछ गड़बड़ हुई</h1><p>कृपया बाद में प्रयास करें।</p>', e.code === 413 ? 413 : 500); });
});
const PORT = process.env.PORT || 3000;
if (require.main === module) server.listen(PORT, () => console.log('LASM site running on http://localhost:' + PORT));
module.exports = server;
