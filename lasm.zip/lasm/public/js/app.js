(function(){
 var b=document.querySelector('.burger'),n=document.getElementById('nav');
 if(b&&n)b.addEventListener('click',function(){var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o);b.setAttribute('aria-label',o?'मेनू बंद करें':'मेनू खोलें')});
 document.addEventListener('click',function(e){
  var a=e.target.closest('a[data-lb]');if(!a)return;e.preventDefault();
  var d=document.createElement('div');d.className='lb';d.setAttribute('role','dialog');d.setAttribute('aria-modal','true');
  d.innerHTML='<button aria-label="बंद करें">×</button><div><img alt=""><p></p></div>';
  d.querySelector('img').src=a.href;d.querySelector('img').alt=a.getAttribute('data-lb');d.querySelector('p').textContent=a.getAttribute('data-lb');
  function close(){d.remove();document.removeEventListener('keydown',k)}function k(ev){if(ev.key==='Escape')close()}
  d.addEventListener('click',function(ev){if(ev.target.tagName!=='IMG')close()});document.addEventListener('keydown',k);document.body.appendChild(d);d.querySelector('button').focus();
 });
})();
