document.addEventListener('submit',function(e){var m=e.target.getAttribute('data-confirm');if(m&&!confirm(m))e.preventDefault()});
document.addEventListener('click',function(e){if(e.target.closest('[data-print]'))print()});
